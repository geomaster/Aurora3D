#include "AuroraNode.h"
#include "AuroraException.h"
using namespace Aurora;

Matrix4 Transform::toMatrix(bool IsQuaternionUnit) const
{
    Matrix4 mat = (IsQuaternionUnit? Rotation.toRotationMatrix4Unit() : Rotation.toRotationMatrix4());
    mat *= Matrix4::fromScale(Scale.getX(), Scale.getY(), Scale.getZ());

    mat.setEntry(0, 3, Translation.getX());
    mat.setEntry(1, 3, Translation.getY());
    mat.setEntry(2, 3, Translation.getZ());

    return mat;
}

void Node::addChild(Node *Child)
{
	String childName = Child->getName();
	if (mChildren.find(childName) != mChildren.end())
	{
        throw DuplicateNameException();
	}
	else
	{
	    Node* oldParent = Child->mParent;
	    oldParent->removeChild(Child);
	    Child->mParent = this;
	    mChildren.insert(std::make_pair(childName, Child));
	}
}

void Node::removeChild(String ChildName)
{
    ChildrenMapIterator it = mChildren.find(ChildName);
    if (it != mChildren.end())
    {
        it->second->mParent = NULL;
        mChildren.erase(it);
    }
}

void Node::removeChild(Node* Child)
{
    removeChild(Child->getName());
}

 void Node::removeAndDestroyChild(Node *Child)
 {
    removeChild(Child->getName());
    delete Child;
 }

void Node::removeAndDestroyChild(String ChildName)
{
    ChildrenMapIterator it = mChildren.find(ChildName);
    if (it != mChildren.end())
    {
        it->second->mParent = NULL;
        mChildren.erase(it);
        delete it->second;
    }
}

void Node::removeAndDestroyChildren()
{
    for (ChildrenMapIterator it = mChildren.begin(); it != mChildren.end(); ++it)
        delete it->second;

    mChildren.clear();
}

Node* Node::getChildByName(String Name)
{
    ChildrenMapIterator it = mChildren.find(Name);
    if (it != mChildren.end())
        return it->second;

    return NULL;
}

void Node::setParent(Node *Parent)
{
    Parent->addChild(this);
}

Transform Node::getAbsoluteTransform() const
 {
     if (!mNeedsUpdate)
        return mAbsoluteTransform;

     if (mIsRoot)
     {
         mNeedsUpdate = false;
         mAbsoluteTransform = mTransform;

         return mAbsoluteTransform;
     }
     else
     {
         Transform parentTransform = mParent->getAbsoluteTransform();
         mAbsoluteTransform = parentTransform.concatenate(mTransform);
         mNeedsUpdate = false;

         return mAbsoluteTransform;
     }
}

Translate Node::_setAbsoluteTransform(const Transform& ParentTransform, bool UpdateChildren)
{
    mAbsoluteTransform = ParentTransform.concatenate(mTransform);
    mNeedsUpdate = false;
    if (UpdateChildren && mChildren.size())
        for (ChildrenMapIterator it = mChildren.begin(); it != mChildren.end(); ++it)
            it->second->_setAbsoluteTransform(mAbsoluteTransform, true);

    return mAbsoluteTransform;
}

void Node::_notifyNeedsUpdate()
{
    mNeedsUpdate = true;
}

Node* Node::createChild(String Name, const Transform& ChildTransform)
{
    Node *node = new Node(Name, this);
    node->setTransform(ChildTransform);
    mChildren.insert(make_pair(Name, node));

    return node;
}

Node* Node::createChild(String Name, const Vector3D& Translation, const Quaternion& Rotation, const Vector3D& Scale)
{
    Node *node = new Node(Name, this);
    Transform t(Translation, Rotation, Scale);
    node->setTransform(t);
    mChildren.insert(make_pair(Name, node));

    return node;
}

Node::~Node()
{
    for (ChildrenMapIterator it = mChildren.begin(); it != mChildren.end(); ++it)
        delete it->second;
}
