#ifndef __AURORA_EXCEPTION_H__
#define __AURORA_EXCEPTION_H__
#include "AuroraPlatform.h"
#include <exception>

#define DEFINE_EXCEPTION(name, description) \
    class name : public Exception \
    { \
    public: \
        const char* what() const throw() \
        { \
            return description; \
        } \
        \
        virtual ~name() throw() \
        { \
        \
        } \
    }

namespace Aurora
{
    class AURORA_LIBRARY Exception : public std::exception
    {
    public:
        Exception() throw()
        {
        }

        Exception(const Exception& other) throw()
        {
        }

        virtual const char* what() const throw()
        {
            return "Generic Aurora exception";
        }

        virtual ~Exception() throw()
        {
        }
    };

    DEFINE_EXCEPTION(UnimplementedException, "An unimplemented feature has been requested.");
    DEFINE_EXCEPTION(DuplicateNameException, "Attempt to add an already-existing node name into the scene graph.");
    DEFINE_EXCEPTION(IllegalOperationException, "Attempt to execute an operation not applicable to current state.");
    DEFINE_EXCEPTION(InternalErrorException, "An internal error has occurred inside Aurora.");
    // TODO: add more exceptions if needed
}

#endif // __AURORA_EXCEPTION_H__
