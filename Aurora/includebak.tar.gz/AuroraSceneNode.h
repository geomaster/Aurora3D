#ifndef __AURORA_SCENENODE_H__
#define __AURORA_SCENENODE_H__
#include "AuroraPlatform.h"
#include "AuroraVector3D.h"
#include "AuroraMatrix3.h"
#include "AuroraQuaternion.h"
#include <boost/unordered_map.hpp>
#include <vector>

using namespace boost;
using namespace std;

#if AURORA_COMPILER == AURORA_COMPILER_MSVC
#pragma warning(push)
#pragma warning(disable:4251) // gets rid of annoying M$'s warning in VC++ regarding the fact that std::string isn't exported.
#endif

namespace Aurora
{
	struct AURORA_LIBRARY Transform
	{
		inline Transform() : Translation(Real( 0.0 )), Rotation(Quaternion::Identity), Scale(Real( 1.0 ))
		{
		}

		inline Transform(const Vector3D& _Translation, const Quaternion& _Rotation, const Vector3D& _Scale) : Translation(_Translation), Rotation(_Rotation), Scale(_Scale)
		{
		}

		Vector3D Translation;
		Quaternion Rotation;
		Vector3D Scale;

		Matrix4 toMatrix(bool IsQuaternionUnit = true) const;

		inline Transform concatenate(const Transform& other) const
		{
			return Transform(Translation + other.Translation, Rotation * other.Rotation, Scale * other.Scale);
		}

		inline void append(const Transform &other)
		{
			Translation += other.Translation;
			Rotation *= other.Rotation;
			Scale *= other.Scale;
		}
	};

	class AURORA_LIBRARY SceneNode
	{
	public:
		typedef boost::unordered_map<String, SceneNode*> ChildrenMap;
		typedef ChildrenMap::iterator ChildrenMapIterator;
		typedef ChildrenMap::const_iterator ChildrenMapConstIterator;

	protected:
		String mName;
		Transform mTransform;
		ChildrenMap mChildren;

		SceneNode *mParent;

        mutable Transform mAbsoluteTransform;
        mutable bool mNeedsUpdate;
        bool mIsRoot;

	public:
/*
		inline SceneNode() : mName(""), mTransform(), mParent(NULL), mNeedsUpdate(true), mIsRoot(false)
		{
		}
*/
		inline SceneNode(String Name, SceneNode *Parent = NULL) : mName(Name), mTransform(), mParent(Parent), mNeedsUpdate(true), mIsRoot(false)
		{
		}

		inline String getName() const
		{
			return mName;
		}

        virtual SceneNode* createChild(String Name, const Transform& ChildTransform = Transform());
        virtual SceneNode* createChild(String Name, const Vector3D& Translation = Vector3D::Zero,
                         const Quaternion& Rotation = Quaternion::Identity,
                         const Vector3D& Scale = Vector3D(Real( 1.0 )));

		virtual void addChild(SceneNode* Child);
		virtual void removeChild(SceneNode* Child);
		virtual void removeChild(String ChildName);
		virtual void removeAndDestroyChild(SceneNode *Child);
		virtual void removeAndDestroyChild(String ChildName);
        virtual void removeAndDestroyChildren();

		virtual SceneNode* getChildByName(String Name);
		virtual void setParent(SceneNode *Parent);

		virtual Transform getAbsoluteTransform() const;
		virtual void _setAbsoluteTransform(const Transform& ParentTransform, bool UpdateChildren);
        virtual void _notifyNeedsUpdate();

        inline virtual void setIsRoot(bool IsRoot)
        {
            mIsRoot = IsRoot;
        }

        inline virtual bool isRoot()
        {
            return mIsRoot;
        }

		inline virtual SceneNode* getParent()
		{
		    return mParent;
		}

		inline const virtual SceneNode* getParent() const
		{
		    return mParent;
		}

		inline virtual ChildrenMapIterator getChildrenIterator()
		{
            return mChildren.begin();
		}

		inline virtual ChildrenMapConstIterator getChildrenIterator() const
		{
		    return mChildren.begin();
		}

		inline virtual Transform getTransform() const
		{
			return mTransform;
		}

		inline virtual void setTransform(const Transform& NewTransform)
		{
			mTransform = NewTransform;
		}

		inline virtual Vector3D getTranslation() const
		{
			return mTransform.Translation;
		}

		inline virtual Quaternion getRotation() const
		{
			return mTransform.Rotation;
		}

		inline virtual Vector3D getScale() const
		{
			return mTransform.Scale;
		}

		inline virtual void setTranslation(const Vector3D& NewTranslation)
		{
			mTransform.Translation = NewTranslation;
		}

		inline virtual void setRotation(const Quaternion& NewRotation)
		{
			mTransform.Rotation = NewRotation;
		}

		inline virtual void setScale(const Vector3D& NewScale)
		{
			mTransform.Scale = NewScale;
		}

        virtual ~SceneNode();
	};
}

#if AURORA_COMPILER == AURORA_COMPILER_MSVC
#pragma warning (pop)
#endif

#endif // __AURORA__SCENENODE_H__
