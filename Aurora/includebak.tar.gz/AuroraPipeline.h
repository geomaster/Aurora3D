#ifndef __AURORA_PIPELINE_H__
#define __AURORA_PIPELINE_H__
#include "AuroraPlatform.h"
#include "AuroraNode.h"

namespace Aurora
{
	class EntityNode;
	class SceneManager;

	enum PipelineType
	{
		EPT_ImmediatePipeline,
		EPT_ListenerPipeline
	};

	class AURORA_LIBRARY Pipeline
	{
	public:
		virtual PipelineType getType() const = 0;
		virtual String getName() const = 0;
		virtual void setSceneManager(SceneManager*) = 0;

		virtual void onFrameStart() = 0;
		virtual void onFrameEnd() = 0;
	};

	class AURORA_LIBRARY ImmediatePipeline : public Pipeline
	{
	public:
		PipelineType getType() const
		{
			return EPT_ImmediatePipeline;
		}

		virtual void queueEntityNode(EntityNode*) = 0;
	};

	class AURORA_LIBRARY ListenerPipeline : public Pipeline
	{
    public:
        PipelineType getType() const
        {
            return EPT_ListenerPipeline;
        }

        virtual void onEntityNodeAdded(EntityNode*) = 0;
        virtual void onEntityNodeRemoved(EntityNode*) = 0;
        virtual void onEntityNodeUpdated(EntityNode*) = 0;
	};
}
#endif // __AURORA_PIPELINE_H__
