#ifndef __AURORAPLATFORM_H__
#define __AURORAPLATFORM_H__
#include "AuroraConfig.h"
#include <boost/unordered_map.hpp>
#include <string>

/**** PLATFORM-RELATED DEFINITIONS ****/

// Compilers
#define AURORA_COMPILER_MSVC			0
#define AURORA_COMPILER_GCC				1
#define AURORA_COMPILER_MINGW			2
#define AURORA_COMPILER_BORLAND			3
#define AURORA_COMPILER_INTEL			4
#define AURORA_COMPILER_UNKNOWN			-1

// Operating systems
#define AURORA_OS_WINDOWS				0
#define AURORA_OS_LINUX					1
#define AURORA_OS_OSX					2
#define AURORA_OS_UNKNOWN				-1

// Processor architectures
#define AURORA_ARCHITECTURE_X86			0
#define AURORA_ARCHITECTURE_X64			1
#define AURORA_ARCHITECTURE_UNKNOWN		-1

// Assembly syntaxes
#define AURORA_SYNTAX_UNAVAILABLE		0
#define AURORA_SYNTAX_ATNT				1
#define AURORA_SYNTAX_INTEL				2

/**** PLATFORM DETECTION ***/

// Detect the compiler
#if defined(_MSC_VER)
#	define AURORA_COMPILER				AURORA_COMPILER_MSVC
#	define AURORA_COMPILER_VERSION		_MSC_VER
#	define AURORA_ASSEMBLY_SYNTAX		AURORA_SYNTAX_INTEL
#elif defined(__GNUC__)
#	define AURORA_COMPILER				AURORA_COMPILER_GCC
#	define AURORA_COMPILER_VERSION		(__GNUC__ * 100) + __GNUC_MINOR__ * 10
#	define AURORA_ASSEMBLY_SYNTAX		AURORA_SYNTAX_ATNT
#elif defined(__MINGW32__)
#	define AURORA_COMPILER				AURORA_COMPILER_MINGW
#	define AURORA_COMPILER_VERSION		(__MINGW32_MAJOR_VERSION * 100) + __MINGW32_MINOR_VERSION * 10
#elif defined(__BORLANDC__)
#	define AURORA_COMPILER				AURORA_COMPILER_BORLAND
#	define AURORA_COMPILER_VERSION		__BORLANDC__
#	define AURORA_ASSEMBLY_SYNTAX		AURORA_SYNTAX_UNAVAILABLE
#elif defined(__INTEL_COMPILER)
#	define AURORA_COMPILER				AURORA_COMPILER_INTEL
#	define AURORA_COMPILER_VERSION		__INTEL_COMPILER
#	define AURORA_ASSEMBLY_SYNTAX		AURORA_SYNTAX_INTEL
#	message("Aurora has detected the Intel compiler. Please compile using -use-msasm option if you want to use inline assembly (or disable it in AuroraConfig.h)")
#else
#	define AURORA_COMPILER				AURORA_COMPILER_UKNOWN
#	define AURORA_ASSEMBLY_SYNTAX		AURORA_SYNTAX_UNAVAILABLE
#	message("Warning: unknown compiler. Aurora will be compiled using generic settings.")
#endif

#if AURORA_ARCHITECTURE == AURORA_ARCHITECTURE_X64 && AURORA_COMPILER == AURORA_COMPILER_MSVC
// Microsoft deleted support for inline assembly on 64bit systems. Time to move to another compiler.
#define AURORA_ASSEMBLY_AVAILABLE		false
#else
#define AURORA_ASSEMBLY_AVAILABLE		(AURORA_ASSEMBLY_SYNTAX != AURORA_SYNTAX_UNAVAILABLE)
#endif

// Detect the operating system
#if defined(_WIN32)
#	define AURORA_OS					AURORA_OS_WINDOWS
#elif defined(__linux__)
#	define AURORA_OS					AURORA_OS_LINUX
#elif defined(__APPLE__) && defined(__MACH__)
#	define AURORA_OS					AURORA_OS_OSX
#else
#	error ("Unsupported operating system!")
#endif

// Detect the underlying processor architecture
#if defined(__amd64__) || defined(__x86_64) || defined(_M_X64) || defined(__ia64__) || defined(_M_IA64)
#	define AURORA_ARCHITECTURE			AURORA_ARCHITECUTRE_X64
#elif defined(i386) || defined(__i386__) || defined (_X86_) || defined(_M_IX86)
#	define AURORA_ARCHITECTURE			AURORA_ARCHITECTURE_X86
#else
#	define AURORA_ARCHITECTURE			AURORA_ARCHITECTURE_UNKNOWN
#	message("Warning: unknown architecture. Aurora will be compiled using generic settings - some features will not be available")
#endif

#if AURORA_COMPILER == AURORA_COMPILER_MSVC
#	if defined(AURORA_SOURCE_BUILD)
#		define AURORA_LIBRARY			__declspec(dllexport)
#	else
#		define AURORA_LIBRARY			__declspec(dllimport)
#	endif
#else
	// On GCC, there are visibility attributes, but everything's public by default.
#	define AURORA_LIBRARY
#endif

#define AURORA_SSE_ENABLED				(AURORA_USE_INLINE_ASSEMBLY && AURORA_ASSEMBLY_AVAILABLE && !AURORA_USE_DOUBLE_PRECISION && AURORA_USE_SSE && (AURORA_COMPILER == AURORA_COMPILER_MSVC || AURORA_COMPILER == AURORA_COMPILER_GCC || AURORA_COMPILER == AURORA_COMPILER_MINGW || AURORA_COMPILER == AURORA_COMPILER_INTEL))

#if AURORA_SSE_ENABLED
#	if AURORA_COMPILER == AURORA_COMPILER_GCC
#		define AURORA_SSE_ALIGN				__attribute__((aligned(16)))
#	elif AURORA_COMPILER == AURORA_COMPILER_MSVC
#		define AURORA_SSE_ALIGN				__declspec(align(16))
#	elif AURORA_COMPILER == AURORA_COMPILER_INTEL
#		define AURORA_SSE_ALIGN				__declspec(align(16))
#	else
#		define AURORA_SSE_ALIGN
#	endif
#else
#		define AURORA_SSE_ALIGN
#endif

#if AURORA_USE_DOUBLE_PRECISION == 0
#define AURORA_FPTOLERANCE				1e-06
#else
#define AURORA_FPTOLERANCE				1e-15
#endif


namespace Aurora
{
	// The type for real numbers
#	if AURORA_USE_DOUBLE_PRECISION == 1
	typedef double Real;
#	else
	typedef float Real;
#	endif

	// Types for characters
	typedef char NarrowCharacter;
	typedef wchar_t WideCharacter;

	// Types for strings
#	if AURORA_USE_WIDE_CHARACTERS == 0
	typedef NarrowCharacter Character;
#	else
	typedef WideCharacter Character;
#	endif

	typedef unsigned char uchar;
	typedef unsigned int uint;
	typedef unsigned long ulong;

	typedef std::basic_string<Character> String;

	// Careful with this macro! An ordinary matrix may be indexed by m[y][x], but parameters to this
	// macro are x, then y.
	// Btw, LEA is short for Load Effective Address, an x86 instruction that does the same as this
	// macro, but with 1D arrays.
#	define LEA2D(x,y,w)			((x)+(y)*(w))

#	if AURORA_USE_DEFAULT_HASH
	typedef boost::hash Hash;
	typedef boost::hash ApproximateHash;
#	endif

}

#endif // __AURORAPLATFORM_H__